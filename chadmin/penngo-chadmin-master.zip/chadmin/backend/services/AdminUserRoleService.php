<?php
namespace backend\services;

use backend\models\AdminUserRole;

class AdminUserRoleService extends AdminUserRole{

   
}
