<?php
namespace backend\services;

use backend\models\AdminUser;

class AdminUserService extends AdminUser{

   
}
