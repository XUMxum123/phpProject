<?php
namespace backend\services;

use backend\models\AdminLog;

class AdminLogService extends AdminLog{

   
}
