<?php
namespace backend\services;

class BaseService
{

   
}

?>