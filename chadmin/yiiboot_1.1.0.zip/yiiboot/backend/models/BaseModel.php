<?php
namespace backend\models;

class BaseModel extends \yii\db\ActiveRecord
{

   
}

?>